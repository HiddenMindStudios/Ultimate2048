return{
  --Added to Settings
  gridOutline = 0,
  gridSize = 80,
  tileCountW = 4,
  tileCountH = 4,
  --NotAdded
  tileColorScheme = "classic",
  tileAnimations = 1,
  screenSize = {w=1920, h=1080},
  fullscreen = 1,
  fullscreenType = "desktop",
  vsync = 1,
  monitor = 1,
  sound = 1,
  music = 1,
  volumeMusic = 1,
  volumeSound = 1
}
