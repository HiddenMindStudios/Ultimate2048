return{
  escape = "goBack",
  left = "moveLeft",
  right = "moveRight",
  up = "moveUp",
  down = "moveDown",
  r = "reset",
  p = "pause"
}