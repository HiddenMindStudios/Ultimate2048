return{
  quit = function() love.event.quit() end
}